import './App.css';
import Navegacion from './components/navbar/navbar';
import Home from './home/home';

function App() {
  return (
  <div>
    <header>
    <Navegacion/>
    </header>
    <Home/>
    
  </div>

    
  );
}

export default App;
